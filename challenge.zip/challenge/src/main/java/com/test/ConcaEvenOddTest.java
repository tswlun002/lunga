package com.test;

import com.programming.techie.ConcaEvenOdd;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ConcaEvenOddTest {
    @Test
    @DisplayName("Test empty string given n=0")
    public  void string_len_0(){
        Assertions.assertEquals("", com.programming.techie.ConcaEvenOdd.jumbleString("",0));
    }
    @Test
    @DisplayName("Test empty string given n>0")
    public  void string_len_greaterThan_zero(){
        Assertions.assertEquals("", com.programming.techie.ConcaEvenOdd.jumbleString("",10000));
    }
    @Test
    @DisplayName("Test  string given n=0")
    public  void n_0(){
        Assertions.assertEquals("Lunga Tsewu", com.programming.techie.ConcaEvenOdd.jumbleString("Lunga Tsewu",0));
    }
    @Test
    @DisplayName("Test  string given n=1")
    public  void n_1(){
        Assertions.assertEquals("LnaTeuug sw", com.programming.techie.ConcaEvenOdd.jumbleString("Lunga Tsewu",1));
    }
    @Test
    @DisplayName("Test  string given n>1")
    public  void n_2(){
        Assertions.assertEquals("LnaTeuug swLnaTeuug sw", ConcaEvenOdd.jumbleString("Lunga Tsewu",2));
    }
    /**
     * Test different inputs with different n values
     * Build an out depending on the given n value by
     * Key on Concatenating expected out n times
     * Assert to equals to output of the jumbleString method
     *
     */
    @ParameterizedTest
    @MethodSource("getExampleAnswer")
    @DisplayName("Test  different string given n")

    public  void  differentString(String input, String expectedOutput,long n){


         //
        StringBuilder newExpected  = new StringBuilder();
        for(var index=0; index<n;index++) {newExpected.append(expectedOutput);}


        Assertions.assertEquals(newExpected.toString(), ConcaEvenOdd.jumbleString(input,n));

    }

    /**
     * We Can use this method  to enter more tests with different string and n(s)
     * @return stream of argument string input, string output and long type n value
     */
    public Stream<Arguments> getExampleAnswer(){
        return Stream.of(
                Arguments.of("He went home", "H ethmewn oe",2), //H ethmewn oe
                Arguments.of("I love java!", "Ilv aa oejv!",2), //Ilv aa oejv!
                Arguments.of("Lets code", "Lt oeescd",2)
        );

    }




}